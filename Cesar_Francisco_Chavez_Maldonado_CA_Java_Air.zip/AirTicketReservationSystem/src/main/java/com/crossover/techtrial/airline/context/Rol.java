package com.crossover.techtrial.airline.context;

public class Rol {
 
	private int id;
	private String name;
	
	public Rol(int id) {
		this.id = id;
	}
	 
}
 
