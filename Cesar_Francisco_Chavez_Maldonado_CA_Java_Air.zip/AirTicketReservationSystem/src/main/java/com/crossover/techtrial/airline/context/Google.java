package com.crossover.techtrial.airline.context;

public class Google implements AuthenticationStrategy {

	@Override
	public void authenticate(String username, String password) {
		// TODO Auto-generated method stub
		
	}
 
}
 
