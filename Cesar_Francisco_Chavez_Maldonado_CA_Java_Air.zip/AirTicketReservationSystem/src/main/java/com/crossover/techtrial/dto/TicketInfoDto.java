package com.crossover.techtrial.dto;

public class TicketInfoDto {
 
}
 
