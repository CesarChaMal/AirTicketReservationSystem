package com.crossover.techtrial.airline.context;

public interface RolStrategy {
	void authenticate(String username, String password);
}
