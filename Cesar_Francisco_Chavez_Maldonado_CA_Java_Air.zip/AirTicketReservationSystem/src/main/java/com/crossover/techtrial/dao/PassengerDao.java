package com.crossover.techtrial.dao;

import com.crossover.techtrial.airline.context.PassengerInterface;
import com.crossover.techtrial.dto.PassengerDto;
import com.crossover.techtrial.rest.CustomerServiceAgentSvc;

public class PassengerDao implements PassengerInterface {
 
	private CustomerServiceAgentSvc customerServiceAgentSvc;
	 
	private PassengerDto passengerDto;
	 
}
 
