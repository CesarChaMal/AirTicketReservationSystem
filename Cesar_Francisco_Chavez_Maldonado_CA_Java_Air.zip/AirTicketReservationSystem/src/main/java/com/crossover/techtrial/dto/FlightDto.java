package com.crossover.techtrial.dto;

import com.crossover.techtrial.dao.FlightDao;

public class FlightDto {
 
	private FlightDao flightDao;
	 
}
 
