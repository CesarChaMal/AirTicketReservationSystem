package com.crossover.techtrial.airline.context;

public interface TicketsSalesAgentInterface {
 
	public abstract void confirmBooking();
	public abstract void bookTicket();
	public abstract void getUserInformation();
}
 
