package com.crossover.techtrial.airline.context;

public class Twitter implements AuthenticationStrategy {

	@Override
	public void authenticate(String username, String password) {
		// TODO Auto-generated method stub
		
	}
 
}
 
