package com.crossover.techtrial.rest;

import com.crossover.techtrial.airline.context.TicketsSalesAgentInterface;

public class TicketsSalesAgentSvc implements TicketsSalesAgentInterface {
 
	/**
	 * @see TicketsSalesAgentInterface#confirmBooking()
	 */
	public void confirmBooking() {
	 
	}
	 
	/**
	 * @see TicketsSalesAgentInterface#bookTicket()
	 */
	public void bookTicket() {
	 
	}
	 
	/**
	 * @see TicketsSalesAgentInterface#getUserInformation()
	 */
	public void getUserInformation() {
	 
	}
	 
}
 
