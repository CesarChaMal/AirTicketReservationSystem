package com.crossover.techtrial.dto;

import com.crossover.techtrial.dao.PassengerDao;

public class PassengerDto {
 
	private PassengerDao passengerDao;
	 
}
 
