package com.crossover.techtrial.rest.helpers;

public class WorkRequestPrimative {
	
	public String ok = null;
	public String result = null;
	public String[] list = null;

	public WorkRequestPrimative()
	{
	}
}
