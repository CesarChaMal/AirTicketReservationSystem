package com.crossover.techtrial.airline.context;

public interface FlightInterface {
 
	public abstract void findAvailableFlights();
}
 
