package com.crossover.techtrial.dao;

import com.crossover.techtrial.airline.context.FlightInterface;
import com.crossover.techtrial.dto.FlightDto;
import com.crossover.techtrial.rest.CustomerServiceAgentSvc;

public class FlightDao implements FlightInterface {
 
	private CustomerServiceAgentSvc customerServiceAgentSvc;
	 
	private FlightDto flightDto;
	 
	public void findAvailableFlights() {
	 
	}
	 
}
 
