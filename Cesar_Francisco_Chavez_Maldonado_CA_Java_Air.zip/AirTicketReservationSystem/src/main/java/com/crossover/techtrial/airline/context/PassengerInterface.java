package com.crossover.techtrial.airline.context;

public interface PassengerInterface {
 
}
 
