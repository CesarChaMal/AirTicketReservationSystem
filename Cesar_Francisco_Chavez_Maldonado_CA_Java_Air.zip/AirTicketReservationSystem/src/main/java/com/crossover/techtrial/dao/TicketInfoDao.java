package com.crossover.techtrial.dao;

import com.crossover.techtrial.airline.context.TicketInfoInterface;

public class TicketInfoDao implements TicketInfoInterface {
 
}
 
