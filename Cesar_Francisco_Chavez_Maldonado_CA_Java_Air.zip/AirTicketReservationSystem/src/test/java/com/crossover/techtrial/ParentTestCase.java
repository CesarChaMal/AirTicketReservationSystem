package com.crossover.techtrial;

import org.junit.Rule;

public class ParentTestCase {
	@Rule
	public MyJUnitStopWatch stopwatch = new MyJUnitStopWatch();
}
